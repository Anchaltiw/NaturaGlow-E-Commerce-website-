import React from 'react'
import './DescriptionBox.css'


export const DescriptionBox = () => {
  return (
    <div className='descriptionbox'>
         <div className="descriptionbox-navigator">
            <div className="descriptionbox-nav-box">Description</div>
            <div className="descriptionbox-nav-box fade">Reviews (122)</div>
         </div>
        <div className="descriptionbox-description">
            <p>
            Our e-commerce website offers a seamless shopping experience, bringing you a diverse selection of high-quality products at competitive prices. With an intuitive design, secure payment options, and quick delivery, it’s never been easier to shop online. Discover deals, browse categories, and find exactly what you need from the comfort of your home.
            </p>
            <p>
            Discover a world of beauty with our website, featuring a wide range of premium skincare and makeup products tailored to every need. Each product is carefully selected to provide quality and effective results, making it easy to find the perfect addition to your beauty routine. Enjoy a user-friendly shopping experience, complete with detailed product insights to help you make the best choice for your skin.
            </p>
        </div> 
    </div>
  )
}
