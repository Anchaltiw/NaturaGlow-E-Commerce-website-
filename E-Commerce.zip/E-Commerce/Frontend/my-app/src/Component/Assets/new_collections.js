import p1_img from "./product_4.png";
import p2_img from "./product_25.png";
import p3_img from "./product_14.png";
import p4_img from "./product_6.png";
import p5_img from "./product_15.png";
import p6_img from "./product_2.png";
import p7_img from "./product_17.png";
import p8_img from "./product_28.png";

let new_collections = [
  {
    id: 4,
    name: "7% ALA & AHA Brightening Face Wash With Vitamin B5 & Glycolic acid For Glowing Skin(100ml)",
    image: p1_img,
    new_price: 399.0,
    old_price: 450.5,
  },
  {
    id: 25,
    name: "Professionnel Absolut Repair Shampoo 300ml",
    image: p2_img,
    new_price: 855.0,
    old_price: 1208.5,
  },
  {
    id: 14,
    name: "Infaillible Grip Upto 36H Gel Automatic Eye Liner - 001 Intense Blackt",
    image: p3_img,
    new_price: 719.0,
    old_price: 1300.5,
  },
  {
    id: 6,
    name: "Under Eye Gel Brightens And Refreshes(20g)",
    image: p4_img,
    new_price: 185.0,
    old_price: 220.0,
  },
  {
    id: 15,
    name: "Barrier Repair Hydrating Lip Balm SPF 50 With Ceramides & Peptides Cherry Crimson(4.5g)",
    image: p5_img,
    new_price: 224.0,
    old_price: 355.5,
  },
  {
    id: 2,
    name: "2% Alpha Arbutin Face Serum With Butylresorcinol & Ferulic Acid For Hyperpigmentation(30ml)",
    image: p6_img,
    new_price: 549.0,
    old_price: 620.5,
  },
  {
    id: 17,
    name: "Voluminous Panorama Waterproof Mascara Volumizing, Clump Free, Smudge free(9.4ml)",
    image: p7_img,
    new_price: 845.0,
    old_price: 1206.5,
  },
  {
    id: 28,
    name: "Advansed Aloe Vera Enriched Coconut Hair Oil for Soft and Strong Hair(250ml)",
    image: p8_img,
    new_price: 185.0,
    old_price: 220.5,
  },
];

export default new_collections;
