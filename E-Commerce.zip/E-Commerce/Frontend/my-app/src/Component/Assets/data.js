import p1_img from './product_1.png'
import p2_img from './product_2.png'
import p3_img from './product_3.png'
import p4_img from './product_4.png'

let data_product = [
  {
    id:1,
    name:"Botanicals Skin Brightening Day Cream with Vitamin CSPF 25 PA+++ Lightweight(50g)",
    image:p1_img,
    new_price:419.00,
    old_price:580.50,
  },
  {id:2,
    name:"2% Alpha Arbutin Face Serum With Butylresorcinol & Ferulic Acid For Hyperpigmentation(30ml)",
    image:p2_img,
    new_price:549.00,
    old_price:620.50,
  },
  {id:3,
    name:"Wanderlust Jaipur Royal Pink Moisturizing Fruity Body Lotion With Pomegranate And Musk(300ml)",
    image:p3_img,
    new_price:550.00,
    old_price:670.50,
  },
  {id:4,
    name:"7% ALA & AHA Brightening Face Wash With Vitamin B5 & Glycolic acid For Glowing Skin(100ml)",
    image:p4_img,
    new_price:399.00,
    old_price:450.00,
  },
];

export default data_product;
