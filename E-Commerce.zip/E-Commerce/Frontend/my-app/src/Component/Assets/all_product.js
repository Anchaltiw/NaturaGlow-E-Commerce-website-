import p1_img from "./product_1.png";
import p2_img from "./product_2.png";
import p3_img from "./product_3.png";
import p4_img from "./product_4.png";
import p5_img from "./product_5.png";
import p6_img from "./product_6.png";
import p13_img from "./product_13.png";
import p14_img from "./product_14.png";
import p15_img from "./product_15.png";
import p16_img from "./product_16.png";
import p17_img from "./product_17.png";
import p18_img from "./product_18.png";
import p25_img from "./product_25.png";
import p26_img from "./product_26.png";
import p27_img from "./product_27.png";
import p28_img from "./product_28.png";
import p29_img from "./product_29.png";
import p30_img from "./product_30.png";


let all_product = [
  {
    id: 1,
    name: " Botanicals Skin Brightening Day Cream with Vitamin CSPF 25 PA+++ Lightweight(50g)",
    category: "skincare",
    image: p1_img,
    new_price: 419.0,
    old_price: 580.5,
  },
  {
    id: 2,
    name: "2% Alpha Arbutin Face Serum With Butylresorcinol & Ferulic Acid For Hyperpigmentation(30ml)",
    category: "skincare",
    image: p2_img,
    new_price: 549.0,
    old_price: 620.5,
  },
  {
    id: 3,
    name: "Wanderlust Jaipur Royal Pink Moisturizing Fruity Body Lotion With Pomegranate And Musk(300ml)",
    category: "skincare",
    image: p3_img,
    new_price: 550.0,
    old_price: 670.5,
  },
  {
    id: 4,
    name: "7% ALA & AHA Brightening Face Wash With Vitamin B5 & Glycolic acid For Glowing Skin(100ml)",
    category: "skincare",
    image: p4_img,
    new_price: 399.0,
    old_price: 450.0,
  },
  {
    id: 5,
    name: "AHA 30% + BHA 2% Peeling Solution (Mini)(15ml)",
    category: "skincare",
    image: p5_img,
    new_price: 609.0,
    old_price: 840.5,
  },
  {
    id: 6,
    name: "Under Eye Gel Brightens And Refreshes(20g)",
    category: "skincare",
    image: p6_img,
    new_price: 185.0,
    old_price: 220.5,
  },
  {
    id: 13,
    name: "Bronson Professional Classic Powder Makeup Brush(10 g)",
    category: "makeup",
    image: p13_img,
    new_price: 85.0,
    old_price: 120.5,
  },
  {
    id: 14,
    name: " Infaillible Grip Upto 36H Gel Automatic Eye Liner - 001 Intense Black",
    category: "makeup",
    image: p14_img,
    new_price: 719.0,
    old_price: 1300.0,
  },
  {
    id: 15,
    name: "Barrier Repair Hydrating Lip Balm SPF 50 With Ceramides & Peptides Cherry Crimson(4.5g)",
    category: "makeup",
    image: p15_img,
    new_price: 224.0,
    old_price: 355.0,
  },
  {
    id: 16,
    name: "All Day Matte Long Lasting Transferproof Liquid Lipstick - Boss Babe(2.1ml)",
    category: "makeup",
    image: p16_img,
    new_price: 255.0,
    old_price: 329.5,
  },
  {
    id: 17,
    name: "Voluminous Panorama Waterproof Mascara Volumizing, Clump Free, Smudge free(9.4ml)",
    category: "makeup",
    image: p17_img,
    new_price: 845.0,
    old_price: 1206.5,
  },
  {
    id: 18,
    name: "Insta Dri Fast Dry Nail Color - Cinna-snap(9.17ml)",
    category: "makeup",
    image: p18_img,
    new_price: 360.0,
    old_price: 459.5,
  },
  
  {
    id: 25,
    name: "Professionnel Absolut Repair Shampoo 300ml",
    category: "hairs",
    image: p25_img,
    new_price: 855.0,
    old_price: 1208.5,
  },
  {
    id: 26,
    name: "Argan Oil And Lavender Anti-frizz Smoothening Shampoo & Conditioner(200ml)",
    category: "hairs",
    image: p26_img,
    new_price: 385.0,
    old_price: 555.5,
  },
  {
    id: 27,
    name: "The Ordinary Multi-Peptide Hair Serum For Denser, Thicker, Healthier Hair (All Hair Types)(60ml)",
    category: "hairs",
    image: p27_img,
    new_price: 485.0,
    old_price: 670.5,
  },
  {
    id: 28,
    name: " Advansed Aloe Vera Enriched Coconut Hair Oil for Soft and Strong Hair(250ml)",
    category: "hairs",
    image: p28_img,
    new_price: 185.0,
    old_price: 220.5,
  },
  {
    id: 29,
    name: "Intense Repair Shampoo For Dry & Damaged Hair(1000ml)",
    category: "hairs",
    image: p29_img,
    new_price: 585.0,
    old_price: 620.5,
  },
  {
    id: 30,
    name: "Anti-Hair Fall Scalp & Hair Serum With Onion, Fenugreek, Redensyl & Caffeine(50ml)",
    category: "hairs",
    image: p30_img,
    new_price: 419.0,
    old_price: 555.5,
  },
];

export default all_product;
